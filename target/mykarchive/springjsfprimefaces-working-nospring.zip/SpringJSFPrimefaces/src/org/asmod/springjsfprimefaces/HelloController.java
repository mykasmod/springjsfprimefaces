package org.asmod.springjsfprimefaces;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class HelloController {
	
	public String showHello(){
		return "HELLO from managed bean";
	}

}
